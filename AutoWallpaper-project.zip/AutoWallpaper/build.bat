@echo off
setlocal
py -m pip install --upgrade pip
py -m pip install -r requirements.txt pyinstaller
py -m PyInstaller --noconfirm --clean --windowed --onefile --name AutoWallpaper --collect-all customtkinter app.py
echo.
echo Build finished. EXE: dist\AutoWallpaper.exe
pause
