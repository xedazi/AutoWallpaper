from __future__ import annotations

import ctypes
import json
import os
import shutil
import sys
import winreg
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox

import customtkinter as ctk
from PIL import Image

APP_NAME = "AutoWallpaper"
APP_VERSION = "1.0.0"
APP_DIR = Path(os.getenv("LOCALAPPDATA", str(Path.home()))) / APP_NAME
CONFIG_PATH = APP_DIR / "settings.json"
WALLPAPER_PATH = APP_DIR / "wallpaper.bmp"
RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
SPI_SETDESKWALLPAPER = 20
SPIF_UPDATEINIFILE = 0x01
SPIF_SENDCHANGE = 0x02

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")


def resource_path(name: str) -> str:
    root = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(root, name)


def load_settings() -> dict:
    try:
        return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {"source_image": "", "wallpapers": [], "startup": False}


def save_settings(settings: dict) -> None:
    APP_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps(settings, indent=2, ensure_ascii=False), encoding="utf-8")


def set_wallpaper(image_path: str) -> None:
    """Convert the selected image to a stable local BMP and apply it on Windows."""
    if sys.platform != "win32":
        raise OSError("AutoWallpaper работает только в Windows 10/11.")
    source = Path(image_path)
    if not source.is_file():
        raise FileNotFoundError("Файл обоев не найден. Выбери изображение заново.")
    APP_DIR.mkdir(parents=True, exist_ok=True)
    with Image.open(source) as image:
        image.convert("RGB").save(WALLPAPER_PATH, "BMP")
    ok = ctypes.windll.user32.SystemParametersInfoW(
        SPI_SETDESKWALLPAPER, 0, str(WALLPAPER_PATH),
        SPIF_UPDATEINIFILE | SPIF_SENDCHANGE
    )
    if not ok:
        raise ctypes.WinError()


def startup_command() -> str:
    if getattr(sys, "frozen", False):
        return f'"{sys.executable}" --apply-only'
    return f'"{sys.executable}" "{os.path.abspath(__file__)}" --apply-only'


def set_startup(enabled: bool) -> None:
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE) as key:
        if enabled:
            winreg.SetValueEx(key, APP_NAME, 0, winreg.REG_SZ, startup_command())
        else:
            try:
                winreg.DeleteValue(key, APP_NAME)
            except FileNotFoundError:
                pass


def apply_saved_wallpaper() -> int:
    settings = load_settings()
    source = settings.get("source_image", "")
    if not source or not os.path.isfile(source):
        return 1
    try:
        set_wallpaper(source)
        return 0
    except Exception:
        return 1


class AutoWallpaperApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.settings = load_settings()
        self.title(f"{APP_NAME} · Настройки")
        self.geometry("820x590")
        self.minsize(740, 540)
        self.configure(fg_color="#0b1020")
        self.selected_path = self.settings.get("source_image", "")
        self.wallpapers = list(self.settings.get("wallpapers", []))
        if not self.wallpapers and self.selected_path:
            self.wallpapers = [self.selected_path]
        self.queue_index = 0

        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        header = ctk.CTkFrame(self, fg_color="transparent")
        header.grid(row=0, column=0, sticky="ew", padx=30, pady=(26, 16))
        ctk.CTkLabel(header, text="AutoWallpaper", font=ctk.CTkFont(size=30, weight="bold"),
                     text_color="#f4f7ff").pack(anchor="w")
        ctk.CTkLabel(header, text="Твои обои. Каждый запуск Windows.",
                     font=ctk.CTkFont(size=14), text_color="#8f9bb8").pack(anchor="w", pady=(3, 0))

        body = ctk.CTkFrame(self, corner_radius=22, fg_color="#131b2e",
                            border_width=1, border_color="#26334e")
        body.grid(row=1, column=0, sticky="nsew", padx=30, pady=(0, 18))
        body.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(body, text="ТЕКУЩИЕ ОБОИ", font=ctk.CTkFont(size=11, weight="bold"),
                     text_color="#7f91b5").grid(row=0, column=0, sticky="w", padx=24, pady=(22, 7))
        self.path_label = ctk.CTkLabel(body, text="Изображение ещё не выбрано",
                                       font=ctk.CTkFont(size=13), text_color="#dce5fa",
                                       anchor="w", justify="left", wraplength=650)
        self.path_label.grid(row=1, column=0, sticky="ew", padx=24, pady=(0, 14))

        queue_header = ctk.CTkFrame(body, fg_color="transparent")
        queue_header.grid(row=2, column=0, sticky="ew", padx=24, pady=(0, 8))
        ctk.CTkLabel(queue_header, text="ОЧЕРЕДЬ ОБОЕВ", font=ctk.CTkFont(size=11, weight="bold"),
                     text_color="#7f91b5").pack(side="left")
        ctk.CTkLabel(queue_header, text="Порядок можно менять", font=ctk.CTkFont(size=11),
                     text_color="#697895").pack(side="right")

        queue_frame = ctk.CTkFrame(body, fg_color="#0e1627", corner_radius=12)
        queue_frame.grid(row=3, column=0, sticky="ew", padx=24, pady=(0, 12))
        queue_frame.grid_columnconfigure(0, weight=1)
        self.queue_list = tk.Listbox(queue_frame, height=4, bg="#0e1627", fg="#dce5fa",
                                     selectbackground="#315b9b", selectforeground="#ffffff",
                                     relief="flat", borderwidth=0, highlightthickness=0,
                                     activestyle="none", font=("Segoe UI", 10))
        self.queue_list.grid(row=0, column=0, rowspan=4, sticky="nsew", padx=(10, 8), pady=10)
        queue_buttons = ctk.CTkFrame(queue_frame, fg_color="transparent")
        queue_buttons.grid(row=0, column=1, sticky="n", padx=(0, 10), pady=10)
        ctk.CTkButton(queue_buttons, text="Добавить", width=100, height=30,
                      command=self.add_to_queue).pack(fill="x", pady=(0, 6))
        ctk.CTkButton(queue_buttons, text="↑ Вверх", width=100, height=30,
                      fg_color="#263652", hover_color="#34496c",
                      command=lambda: self.move_queue(-1)).pack(fill="x", pady=(0, 6))
        ctk.CTkButton(queue_buttons, text="↓ Вниз", width=100, height=30,
                      fg_color="#263652", hover_color="#34496c",
                      command=lambda: self.move_queue(1)).pack(fill="x", pady=(0, 6))
        ctk.CTkButton(queue_buttons, text="Убрать", width=100, height=30,
                      fg_color="#512c3b", hover_color="#6a3549",
                      command=self.remove_from_queue).pack(fill="x")

        buttons = ctk.CTkFrame(body, fg_color="transparent")
        buttons.grid(row=4, column=0, sticky="w", padx=24, pady=(0, 18))
        ctk.CTkButton(buttons, text="Применить выбранные обои", height=40, corner_radius=12,
                      command=self.apply_now).pack(side="left", padx=(0, 10))
        ctk.CTkButton(buttons, text="Применить следующий", height=40, corner_radius=12,
                      fg_color="#263652", hover_color="#34496c",
                      command=self.apply_next).pack(side="left")
        separator = ctk.CTkFrame(body, height=1, fg_color="#26334e")
        separator.grid(row=5, column=0, sticky="ew", padx=24, pady=(0, 18))

        ctk.CTkLabel(body, text="АВТОМАТИЗАЦИЯ", font=ctk.CTkFont(size=11, weight="bold"),
                     text_color="#7f91b5").grid(row=6, column=0, sticky="w", padx=24, pady=(0, 10))
        self.startup_var = tk.BooleanVar(value=bool(self.settings.get("startup", False)))
        self.startup_switch = ctk.CTkSwitch(
            body, text="Восстанавливать обои при входе в Windows",
            variable=self.startup_var, command=self.toggle_startup,
            font=ctk.CTkFont(size=14), progress_color="#4f8cff"
        )
        self.startup_switch.grid(row=7, column=0, sticky="w", padx=24, pady=(0, 8))
        ctk.CTkLabel(body, text="Приложение добавит запись автозапуска только для твоей учётной записи.",
                     font=ctk.CTkFont(size=12), text_color="#8f9bb8").grid(
                         row=8, column=0, sticky="w", padx=24, pady=(0, 18))

        footer = ctk.CTkFrame(self, fg_color="transparent")
        footer.grid(row=2, column=0, sticky="ew", padx=32, pady=(0, 18))
        ctk.CTkLabel(footer, text=f"Версия {APP_VERSION}  •  Windows 10/11",
                     font=ctk.CTkFont(size=11), text_color="#697895").pack(side="left")
        ctk.CTkButton(footer, text="Открыть папку настроек", height=32,
                      fg_color="transparent", border_width=1, border_color="#34415d",
                      hover_color="#18243a", command=self.open_settings_folder).pack(side="right")

        self.refresh_path()
        self.refresh_queue()

    def refresh_queue(self):
        self.queue_list.delete(0, tk.END)
        for i, path in enumerate(self.wallpapers):
            name = os.path.basename(path)
            if not os.path.isfile(path):
                name += "  (файл не найден)"
            self.queue_list.insert(tk.END, f"{i + 1}. {name}")
        if self.wallpapers:
            self.queue_list.selection_set(min(self.queue_index, len(self.wallpapers) - 1))

    def persist_queue(self):
        self.settings["wallpapers"] = list(self.wallpapers)
        self.settings["source_image"] = self.selected_path
        save_settings(self.settings)
        self.refresh_queue()

    def add_to_queue(self):
        paths = filedialog.askopenfilenames(
            title="Добавить изображения в очередь",
            filetypes=[("Изображения", "*.jpg *.jpeg *.png *.bmp *.webp"), ("Все файлы", "*.*")]
        )
        if not paths:
            return
        added = 0
        for path in paths:
            try:
                with Image.open(path) as im:
                    im.verify()
            except Exception:
                continue
            if path not in self.wallpapers:
                self.wallpapers.append(path)
                added += 1
        if added == 0:
            messagebox.showinfo("Очередь не изменилась", "Новые корректные изображения не добавлены.")
        self.persist_queue()

    def move_queue(self, delta):
        selection = self.queue_list.curselection()
        if not selection:
            return
        index = selection[0]
        target = index + delta
        if target < 0 or target >= len(self.wallpapers):
            return
        self.wallpapers[index], self.wallpapers[target] = self.wallpapers[target], self.wallpapers[index]
        self.queue_index = target
        self.persist_queue()

    def remove_from_queue(self):
        selection = self.queue_list.curselection()
        if not selection:
            return
        index = selection[0]
        removed = self.wallpapers.pop(index)
        if self.selected_path == removed:
            self.selected_path = self.wallpapers[0] if self.wallpapers else ""
        self.queue_index = min(index, max(0, len(self.wallpapers) - 1))
        self.persist_queue()
        self.refresh_path()

    def apply_next(self):
        if not self.wallpapers:
            messagebox.showinfo("Очередь пуста", "Добавь изображения в очередь.")
            return
        selection = self.queue_list.curselection()
        current = selection[0] if selection else self.queue_index
        next_index = (current + 1) % len(self.wallpapers)
        self.queue_index = next_index
        self.selected_path = self.wallpapers[next_index]
        self.refresh_path()
        self.refresh_queue()
        self.apply_now()

    def refresh_path(self):
        if self.selected_path and os.path.isfile(self.selected_path):
            self.path_label.configure(text=self.selected_path)
        elif self.selected_path:
            self.path_label.configure(text="Файл не найден — выбери изображение заново.\n" + self.selected_path)
        else:
            self.path_label.configure(text="Изображение ещё не выбрано")

    def choose_image(self):
        self.add_to_queue()
        if self.wallpapers:
            selection = self.queue_list.curselection()
            if selection:
                self.selected_path = self.wallpapers[selection[0]]
                self.refresh_path()

    def apply_now(self):
        selection = self.queue_list.curselection() if hasattr(self, "queue_list") else ()
        if selection and self.wallpapers:
            self.queue_index = selection[0]
            self.selected_path = self.wallpapers[self.queue_index]
        if not self.selected_path:
            messagebox.showinfo("Сначала выбери обои", "Добавь изображение в очередь.")
            return
        try:
            set_wallpaper(self.selected_path)
            self.settings["source_image"] = self.selected_path
            self.settings["wallpapers"] = list(self.wallpapers)
            save_settings(self.settings)
            messagebox.showinfo("Готово", "Обои успешно установлены.")
        except Exception as exc:
            messagebox.showerror("Не удалось установить обои", str(exc))

    def toggle_startup(self):
        enabled = bool(self.startup_var.get())
        try:
            set_startup(enabled)
            self.settings["startup"] = enabled
            save_settings(self.settings)
        except Exception as exc:
            self.startup_var.set(not enabled)
            messagebox.showerror("Ошибка автозапуска", str(exc))

    def open_settings_folder(self):
        APP_DIR.mkdir(parents=True, exist_ok=True)
        os.startfile(str(APP_DIR))


def main():
    if sys.platform != "win32":
        print("AutoWallpaper предназначен для Windows 10/11.")
        return 1
    if "--apply-only" in sys.argv:
        return apply_saved_wallpaper()
    app = AutoWallpaperApp()
    app.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
